/* ===== CURSOR & SCROLL ===== */
function initCursorScroll() {
  const cur = document.getElementById('cursor'), ring = document.getElementById('cursor-ring');
  if (!cur) return;
  let rx = 0, ry = 0;
  document.addEventListener('mousemove', e => {
    cur.style.left = e.clientX + 'px'; cur.style.top = e.clientY + 'px';
    rx += (e.clientX - rx) * .12; ry += (e.clientY - ry) * .12;
    ring.style.left = rx + 'px'; ring.style.top = ry + 'px';
  });
  setInterval(() => { ring.style.left = rx + 'px'; ring.style.top = ry + 'px'; }, 16);
  document.addEventListener('mousedown', () => cur.style.transform = 'translate(-50%,-50%) scale(.5)');
  document.addEventListener('mouseup', () => cur.style.transform = 'translate(-50%,-50%) scale(1)');
  window.addEventListener('scroll', () => {
    const sp = document.getElementById('scroll-progress');
    if (sp) sp.style.width = (window.scrollY / (document.body.scrollHeight - window.innerHeight) * 100) + '%';
    const nav = document.querySelector('nav');
    if (nav) nav.classList.toggle('scrolled', window.scrollY > 50);
  });
}

/* ===== PARTICLES ===== */
function initParticles(containerId, color = 'rgba(126,200,160,.4)') {
  const c = document.getElementById(containerId);
  if (!c) return;
  for (let i = 0; i < 30; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.cssText = `left:${Math.random()*100}%;animation-duration:${7+Math.random()*10}s;animation-delay:${Math.random()*8}s;width:${2+Math.random()*4}px;height:${2+Math.random()*4}px;background:${color};`;
    c.appendChild(p);
  }
}

/* ===== SCROLL REVEAL ===== */
function initReveal() {
  const obs = new IntersectionObserver(entries => entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); }), { threshold: .12 });
  document.querySelectorAll('.reveal, .theory-card, .explore-card').forEach(el => obs.observe(el));
}

/* ===== THEORY TABS ===== */
function initTheoryTabs() {
  document.querySelectorAll('.theory-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const pane = tab.dataset.pane;
      document.querySelectorAll('.theory-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.theory-pane').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(pane).classList.add('active');
    });
  });
  const firstTab = document.querySelector('.theory-tab');
  if (firstTab) firstTab.click();
}

/* ===== TIMER ===== */
function initTimer(totalMinutes) {
  const fill = document.getElementById('timerFill');
  const timeEl = document.getElementById('timerTime');
  if (!fill || !timeEl) return;
  const total = totalMinutes * 60;
  let elapsed = 0;
  const iv = setInterval(() => {
    elapsed++;
    const pct = Math.min(elapsed / total * 100, 100);
    fill.style.width = pct + '%';
    const rem = Math.max(total - elapsed, 0);
    timeEl.textContent = `${Math.floor(rem / 60)}:${String(rem % 60).padStart(2, '0')} до конца`;
    if (elapsed >= total) clearInterval(iv);
  }, 1000);
}

/* ====================================================
   QUESTION BANKS BY GRADE
   ==================================================== */

const QB = {}; // QB[grade] = array of question objects

QB.base = [
  // ТЕМА: Настроение
  {theme:'Настроение',text:'Какую основную функцию выполняет пейзаж?',quote:'«Дождь лил не переставая. Серые лужи расплывались по двору, небо давило низко и беззвёздно.»',opts:['Создаёт мрачное, угнетающее настроение','Обозначает точное время суток','Предсказывает гибель героя','Является символом свободы'],correct:0,exp:'Описание дождя и низкого неба нагнетает тревожную атмосферу — функция создания настроения.'},
  {theme:'Настроение',text:'Автор хочет передать радость и лёгкость. Какой пейзаж подойдёт лучше всего?',opts:['Чёрные тучи, гром, ливень','Пожелтевшие листья в грязи','Майское утро, первые лучи, пение птиц','Промёрзший пруд под серым небом'],correct:2,exp:'Майское утро — классический образ лёгкости и радости.'},
  {theme:'Настроение',text:'Зачем Чехов часто открывает рассказ описанием природы?',opts:['Показать знание ботаники','Задать тональность и погрузить читателя в мир','Заполнить пространство текста','Требование редакции'],correct:1,exp:'Пейзаж в начале — "камертон" всего текста.'},
  {theme:'Настроение',text:'Какая деталь НАРУШАЕТ тревожное настроение?',opts:['Воронье карканье','Сухой треск ветвей','Ребёнок, кормящий уток в пруду','Туман над полем'],correct:2,exp:'Идиллическая сцена с ребёнком разрушает тревогу.'},
  {theme:'Настроение',text:'Описание цветущей черёмухи создаёт...',opts:['Угнетающее настроение','Лёгкое, радостное, весеннее настроение','Ощущение угрозы','Меланхолию'],correct:1,exp:'Цветущая черёмуха — один из сильнейших образов весенней радости в русской литературе.'},
  {theme:'Настроение',text:'Эпитет «мёртвая тишина» в описании природы создаёт ощущение...',opts:['Покоя и уюта','Тревоги и напряжения','Радостного ожидания','Игривого настроения'],correct:1,exp:'"Мёртвая тишина" — зловещий образ, нагнетающий тревогу.'},
  {theme:'Настроение',text:'Тихий летний вечер с запахом сена создаёт...',opts:['Тревогу','Покой и умиротворение','Предчувствие беды','Грусть'],correct:1,exp:'Летний вечер с сенокосом — образ покоя и неторопливости.'},
  {theme:'Настроение',text:'«Небо горело заревом» — в каком случае создаёт тревогу?',opts:['Рассвет перед свадьбой','Начало войны или пожара','Начало путешествия','Картина мирного лета'],correct:1,exp:'Зарево в контексте войны или пожара — образ катастрофы.'},
  {theme:'Настроение',text:'Осенний пейзаж. Что усилит меланхолию?',opts:['Яркие краски листвы, солнце','Голые чёрные ветви, морось, туман','Грибники с корзинами','Дети в резиновых сапогах'],correct:1,exp:'Голые ветви в тумане — образ осенней меланхолии.'},
  {theme:'Настроение',text:'Какой образ сильнее передаст ощущение одиночества?',opts:['Весёлая поляна','Одинокое дерево на холме в тумане','Цветущий луг','Берёзовая роща в мае'],correct:1,exp:'Одинокое дерево в тумане — метафора изоляции.'},
  // ТЕМА: Психологический параллелизм
  {theme:'Параллелизм',text:'Какой приём использует автор?',quote:'«На душе у Наташи было тихо и пусто, как в зимнем поле без следов.»',opts:['Предсказание событий','Психологический параллелизм','Обозначение времени года','Символ свободы'],correct:1,exp:'Пустота поля параллельна пустоте в душе — классический параллелизм.'},
  {theme:'Параллелизм',text:'Персонаж узнал радостную новость. Как работает параллелизм?',opts:['Описывается метель','Упоминается ворон','Вводится весеннее солнце и цветущие сады','Показывается засохшее дерево'],correct:2,exp:'Весна параллельна радости персонажа.'},
  {theme:'Параллелизм',text:'«Листья падали молча, как слёзы.» Это пример...',opts:['Пейзажа-фона','Психологического параллелизма с метафорой','Предсказания зимы','Временно́го маркера'],correct:1,exp:'Листья = слёзы — параллелизм через метафору.'},
  {theme:'Параллелизм',text:'«За окном всё цвело, но Андрей не замечал — в душе его была зима.» Функция пейзажа:',opts:['Радостное настроение','Контрастный параллелизм','Предсказание беды','Символ смерти'],correct:1,exp:'Антитетический параллелизм: весна снаружи — зима внутри.'},
  {theme:'Параллелизм',text:'«Ночь была непроглядной, беззвёздной» когда герой переживает горе. Это...',opts:['Временной маркер','Символика','Психологический параллелизм','Фон'],correct:2,exp:'Тёмная ночь параллельна горю — внешний мрак = внутренний.'},
  {theme:'Параллелизм',text:'«Она плакала, и дождь за окном плакал вместе с ней» — это...',opts:['Символика','Психологический параллелизм','Временной маркер','Предсказание'],correct:1,exp:'Прямое уподобление дождя слезам — выразительный параллелизм.'},
  {theme:'Параллелизм',text:'«Вокруг было темно, как и в его мыслях.» Это...',opts:['Временной маркер','Психологический параллелизм','Предсказание беды','Символика'],correct:1,exp:'Тёмное пространство = тёмные мысли — явный параллелизм.'},
  {theme:'Параллелизм',text:'«Сердце её сжималось, как листва под первым морозом.» Это...',opts:['Временной маркер','Символика мороза','Психологический параллелизм','Предсказание'],correct:2,exp:'Сжимающееся сердце = листва под морозом — параллелизм+метафора.'},
  {theme:'Параллелизм',text:'Герой принимает решение. За окном — ясный день с пением птиц. Автор...',opts:['Просто описывает погоду','Параллелит ясность и решимость','Предсказывает беду','Обозначает время'],correct:1,exp:'Ясный день параллелит ясность и решимость персонажа.'},
  {theme:'Параллелизм',text:'«Старый сад зарастал, как зарастала память о прошлом.» Это...',opts:['Символика сада','Психологический параллелизм','Предсказание','Временной фон'],correct:1,exp:'Запустение сада = угасание памяти — параллелизм+метафора.'},
  // ТЕМА: Символика
  {theme:'Символика',text:'Что традиционно символизирует туман?',opts:['Конец жизни','Неопределённость и тайну','Начало весны','Радость'],correct:1,exp:'Туман — неопределённость, непознанное, скрытое.'},
  {theme:'Символика',text:'В каком варианте пейзаж выполняет роль символа, а не фона?',opts:['«Третий час дня, солнце высоко»','«Старый дуб один стоял — все ровесники срублены»','«Дул северный ветер»','«Температура упала до нуля»'],correct:1,exp:'Одинокий дуб — символ стойкости или одиночества.'},
  {theme:'Символика',text:'Море в романтической литературе чаще всего символизирует...',opts:['Скуку и однообразие','Свободу, безграничность, стихию','Смерть','Богатство'],correct:1,exp:'Море — символ свободы и безграничных возможностей.'},
  {theme:'Символика',text:'«Дорога уходила и терялась в тумане.» — финал романа. Это скорее всего...',opts:['Географический ориентир','Символ открытого финала','Предсказание смерти','Описание осени'],correct:1,exp:'Дорога в тумане — символ открытого будущего.'},
  {theme:'Символика',text:'Засохшее дерево в тексте — символ...',opts:['Долголетия','Смерти, конца, угасания','Весны','Силы'],correct:1,exp:'Засохшее дерево — образ смерти и угасания.'},
  {theme:'Символика',text:'Весна в большинстве текстов символизирует...',opts:['Угасание','Обновление, надежду, начало','Старость','Разлуку'],correct:1,exp:'Весна — универсальный символ обновления и надежды.'},
  {theme:'Символика',text:'Лес в сказках и литературе символизирует...',opts:['Открытое пространство','Тайну, испытание, границу миров','Богатство','Скуку'],correct:1,exp:'Лес — архетипический образ тайны и испытания.'},
  {theme:'Символика',text:'Закат в романтической традиции символизирует...',opts:['Начало нового','Конец, угасание, прощание','Радость','Силу'],correct:1,exp:'Закат — завершение, прощание, угасание.'},
  {theme:'Символика',text:'Зеркальная гладь озера символизирует...',opts:['Опасность','Покой, созерцание, отражение внутреннего','Богатство','Скуку'],correct:1,exp:'Спокойная вода — символ созерцания и покоя.'},
  {theme:'Символика',text:'Дождь в романтической литературе символизирует...',opts:['Скуку','Очищение, слёзы, обновление','Богатство','Силу'],correct:1,exp:'Дождь — слёзы, очищение, новое начало.'},
  {theme:'Символика',text:'Белая берёза у Есенина — это прежде всего...',opts:['Описание дерева','Символ России, чистоты, родины','Временной маркер','Пейзажный фон'],correct:1,exp:'Берёза у Есенина — символ родины и чистоты.'},
  // ТЕМА: Предчувствие
  {theme:'Предчувствие',text:'Какой пейзаж создаёт предчувствие беды?',opts:['Ясное звёздное небо','Огромная чёрная туча заслонила солнце','Радуга после дождя','Лёгкие белые облака'],correct:1,exp:'Надвигающаяся туча — классическое предзнаменование беды.'},
  {theme:'Предчувствие',text:'Перед объяснением в любви. Какой пейзаж создаёт надежду?',opts:['Осенний листопад','Надвигающийся шторм','Рассвет: небо светлеет, птицы поют','Промёрзшая дорога в тумане'],correct:2,exp:'Рассвет — начало, надежда, возможность.'},
  {theme:'Предчувствие',text:'Гроза в середине произведения чаще всего...',opts:['Просто описание погоды','Предвещает переломный момент','Означает конец романа','Символизирует дружбу'],correct:1,exp:'Гроза — традиционный образ конфликта и перелома.'},
  {theme:'Предчувствие',text:'Тихое безоблачное небо перед сражением создаёт...',opts:['Покой без подтекста','Зловещий контраст — спокойствие перед бурей','Символ победы','Временной маркер'],correct:1,exp:'Обманчивый покой — контрастное предзнаменование.'},
  {theme:'Предчувствие',text:'Неожиданный снег в мае — это чаще всего...',opts:['Каприз природы','Тревожный знак, нарушение порядка','Символ радости','Временной маркер'],correct:1,exp:'Нарушение природного порядка — сигнал тревоги.'},
  {theme:'Предчувствие',text:'Автор описывает яркие звёзды накануне трагедии. Это...',opts:['Случайная деталь','Красота перед катастрофой — усиление трагизма','Символ богатства','Временной маркер'],correct:1,exp:'Гиперболическая красота перед катастрофой — приём "красивой гибели".'},
  {theme:'Предчувствие',text:'Замолчавшие птицы в лесу — это...',opts:['Деталь тишины','Тревожный сигнал, предвестник опасности','Символ смерти птиц','Временной маркер'],correct:1,exp:'Замолчавшие птицы — природный сигнал тревоги.'},
  {theme:'Предчувствие',text:'В «Капитанской дочке» метель в момент встречи с Пугачёвым — это...',opts:['Просто зимняя погода','Предзнаменование судьбоносного события','Символ смерти','Временной фон'],correct:1,exp:'Метель — судьбоносный природный знак встречи.'},
  {theme:'Предчувствие',text:'Красный закат накануне трагедии — это...',opts:['Красивая деталь','Зловещее предзнаменование','Символ богатства','Временной маркер'],correct:1,exp:'Кровавый закат — предзнаменование катастрофы.'},
  // ТЕМА: Временной фон
  {theme:'Временной фон',text:'Автор хочет показать конец эпохи, увядание. Какой сезон выберет?',opts:['Ранняя весна','Жаркое лето','Поздняя осень','Зимнее солнцестояние'],correct:2,exp:'Поздняя осень — образ увядания и конца.'},
  {theme:'Временной фон',text:'«Трава пожухла, заморозки серебрили лужи» — маркер...',opts:['Конца весны','Ранней осени','Середины лета','Февраля'],correct:1,exp:'Пожухшая трава и заморозки — маркеры ранней осени.'},
  {theme:'Временной фон',text:'«Тающий снег и набухшие почки» указывает на...',opts:['Конец лета','Начало весны','Позднюю осень','Зиму'],correct:1,exp:'Тающий снег и почки — маркеры ранней весны.'},
  {theme:'Временной фон',text:'«Звёзды блекнут, горизонт светлеет» — это...',opts:['Ночь в разгаре','Рассвет','Полдень','Сумерки'],correct:1,exp:'Блекнущие звёзды и светлеющий горизонт — маркеры рассвета.'},
  {theme:'Временной фон',text:'Описание времён года в эпическом романе...',opts:['Только декоративное','Структурирует текст и создаёт цикличность','Всегда символично','Только настроение'],correct:1,exp:'Смена сезонов — структурный элемент и образ цикличности.'},
  {theme:'Временной фон',text:'Начало июня, густая листва. Это указывает на...',opts:['Весну','Разгар лета','Осень','Зиму'],correct:1,exp:'Густая тёмная листва — признак начала лета.'},
  {theme:'Временной фон',text:'Метель в начале главы выполняет роль...',opts:['Только погодного фона','Временно́го маркера и нагнетателя угрозы','Символа радости','Параллелизма к счастью'],correct:1,exp:'Метель — временной маркер (зима) и нагнетатель атмосферы.'},
  {theme:'Временной фон',text:'Для чего автор детально описывает природу в начале каждой части?',opts:['Показать знание природы','Структурировать текст и ощущение времени','Заполнить объём','Развлечь читателя'],correct:1,exp:'Пейзаж в начале части — структурный элемент.'},
];

// Дополнительные вопросы по произведениям для старших классов
QB.works = {
  'Гроза (Островский)': [
    {theme:'Произведение',text:'Гроза в пьесе Островского «Гроза» является символом...',opts:['Буйства природы','Внутренней свободы Катерины и неизбежности расплаты','Богатства Кабанихи','Счастья Тихона'],correct:1,exp:'Гроза — центральный символ пьесы: внутренняя буря Катерины и неизбежная расплата.'},
    {theme:'Произведение',text:'Волга в «Грозе» Островского символизирует...',opts:['Богатство города Калинова','Свободу и смерть как освобождение для Катерины','Торговые пути','Красоту природы'],correct:1,exp:'Волга для Катерины — символ свободы, а в финале — путь к освобождению через смерть.'},
    {theme:'Произведение',text:'Пейзаж в начале «Грозы» с видом на Волгу создаёт...',opts:['Ощущение свободы и простора в контрасте с духотой жизни героини','Радостное настроение','Предчувствие богатства','Зимнее настроение'],correct:0,exp:'Просторная Волга контрастирует с "тёмным царством" — духотой жизни Катерины.'},
  ],
  'Капитанская дочка (Пушкин)': [
    {theme:'Произведение',text:'Метель в «Капитанской дочке» Пушкина — это прежде всего...',opts:['Погодное явление','Символ судьбы, заносящей Гринёва к Пугачёву','Признак зимы','Образ смерти'],correct:1,exp:'Метель — символ судьбы и стихии истории, направляющей героя.'},
    {theme:'Произведение',text:'Пугачёв в метели у Пушкина сравнивается с...',opts:['Орлом','Волком','Медведем','Лисицей'],correct:0,exp:'Пугачёв — орёл в народной песне: вольная птица, живущая ярко, хотя и недолго.'},
  ],
  'Война и мир (Толстой)': [
    {theme:'Произведение',text:'Небо Аустерлица у Толстого, которое видит раненый Андрей, символизирует...',opts:['Победу русских','Бесконечность, истину, смысл жизни выше суеты','Смерть','Красоту природы'],correct:1,exp:'Высокое небо — откровение: бесконечность и истинные ценности выше военной славы.'},
    {theme:'Произведение',text:'Дуб, встреченный Болконским по дороге в Отрадное, а потом в цвету, символизирует...',opts:['Силу России','Духовное возрождение Андрея','Любовь к Наташе','Старость'],correct:1,exp:'Мёртвый дуб — душа Андрея; расцветший дуб — её пробуждение к жизни.'},
    {theme:'Произведение',text:'Ночь в Отрадном, когда Наташа смотрит на звёзды, создаёт...',opts:['Тревожное настроение','Образ живой жизненной силы, контрастирующей с рационализмом Андрея','Предчувствие войны','Символ смерти'],correct:1,exp:'Восторг Наташи — живая сила, которая пробуждает в Андрее интерес к жизни.'},
  ],
  'Мцыри (Лермонтов)': [
    {theme:'Произведение',text:'Кавказские горы в «Мцыри» Лермонтова символизируют...',opts:['Опасность','Свободу, родину, мечту героя','Смерть','Богатство'],correct:1,exp:'Горы для Мцыри — символ свободы и недостижимой родины.'},
    {theme:'Произведение',text:'Гроза в «Мцыри», которую герой встречает с восторгом, отражает...',opts:['Страх перед стихией','Родство его мятежной души со стихийными силами природы','Предчувствие смерти','Красоту Кавказа'],correct:1,exp:'Гроза близка Мцыри: его душа так же бурна и свободна.'},
  ],
  'Мёртвые души (Гоголь)': [
    {theme:'Произведение',text:'Дорога в «Мёртвых душах» Гоголя — это прежде всего символ...',opts:['Конкретного путешествия Чичикова','Пути России, поиска национальной судьбы','Богатства помещиков','Смерти'],correct:1,exp:'Дорога — центральный образ поэмы: путь России, вопрос о её судьбе.'},
    {theme:'Произведение',text:'Описание усадьбы Плюшкина через запустевший сад символизирует...',opts:['Красоту осени','Духовное разложение и омертвение хозяина','Богатство поместья','Приход зимы'],correct:1,exp:'Зарастающий сад — образ духовного омертвения Плюшкина.'},
  ],
  'Вишнёвый сад (Чехов)': [
    {theme:'Произведение',text:'Вишнёвый сад у Чехова — прежде всего символ...',opts:['Богатства семьи','Уходящей эпохи, красоты и прошлого','Будущего процветания','Любви героев'],correct:1,exp:'Вишнёвый сад — символ уходящего прекрасного прошлого и культуры.'},
    {theme:'Произведение',text:'Звук лопнувшей струны в «Вишнёвом саде» — это...',opts:['Реальный звук','Символ конца старого мира','Предчувствие любви','Звук природы'],correct:1,exp:'Лопнувшая струна — мистический символ разрыва с прошлым, конца эпохи.'},
  ],
  'Слово о полку Игореве': [
    {theme:'Произведение',text:'Затмение солнца в «Слове о полку Игореве» — это...',opts:['Астрономическое явление','Зловещее предзнаменование поражения Игоря','Красивая деталь','Символ победы'],correct:1,exp:'Затмение — природный знак, предвещающий поражение и беду.'},
    {theme:'Произведение',text:'Природа в «Слове» воет и плачет вместе с русскими воинами. Это пример...',opts:['Психологического параллелизма','Символики','Временно́го маркера','Предсказания'],correct:0,exp:'Природа переживает горе вместе с людьми — расширенный параллелизм.'},
  ],
  'Тихий Дон (Шолохов)': [
    {theme:'Произведение',text:'Дон в «Тихом Доне» Шолохова символизирует...',opts:['Торговые пути','Жизнь, судьбу казачества, непрерывность бытия','Богатство','Смерть'],correct:1,exp:'Дон — образ вечной жизни, судьбы казачества и родины.'},
    {theme:'Произведение',text:'Степь в начале романа Шолохова создаёт...',opts:['Образ ограниченного пространства','Ощущение бесконечной воли, простора казачьей жизни','Предчувствие трагедии','Символ богатства'],correct:1,exp:'Донская степь — образ воли, широты казачьей судьбы.'},
  ],
  'Евгений Онегин (Пушкин)': [
    {theme:'Произведение',text:'Зима в «Евгении Онегине» связана прежде всего с образом...',opts:['Онегина','Татьяны — её душа родственна зиме','Ленского','Ольги'],correct:1,exp:'Татьяна любит зиму; зимний пейзаж — её душевный мир.'},
    {theme:'Произведение',text:'Осенний пейзаж в «Евгении Онегине» чаще всего выражает...',opts:['Радость Пушкина','Авторскую меланхолию и размышление о жизни','Веселье деревни','Богатство поместья'],correct:1,exp:'Осень — любимое время Пушкина: меланхолия, творчество, размышление.'},
  ],
};

/* ===== GET QUESTIONS FOR GRADE ===== */
function getQuestionsForGrade(grade) {
  const base = [...QB.base];
  const grade_extra = {
    7: [
      {theme:'Введение',text:'Пейзаж в тексте — это...',opts:['Описание персонажей','Описание природы и окружающей среды','Описание диалогов','Авторские рассуждения'],correct:1,exp:'Пейзаж — описание природы: неба, леса, погоды, времени суток.'},
      {theme:'Введение',text:'Зачем автор описывает природу?',opts:['Чтобы заполнить страницу','Чтобы воздействовать на читателя и создать атмосферу','Это случайные детали','Требование учебника'],correct:1,exp:'Каждая пейзажная деталь выбрана автором намеренно.'},
      {theme:'Введение',text:'Какую роль играет пейзаж в сказке?',opts:['Описывает маршрут','Создаёт волшебную атмосферу и подчёркивает опасность','Называет животных','Показывает погоду'],correct:1,exp:'В сказке пейзаж усиливает волшебство и опасность.'},
    ],
    8: [
      {theme:'Углубление',text:'Психологический параллелизм — это...',opts:['Сравнение двух персонажей','Соответствие природы внутреннему состоянию героя','Параллельные сюжетные линии','Описание двух пейзажей'],correct:1,exp:'Параллелизм: природа отражает душу персонажа.'},
      {theme:'Углубление',text:'Антитетический параллелизм — это...',opts:['Совпадение природы и настроения','Контраст: природа и настроение противоположны','Описание противоположных сезонов','Два разных персонажа'],correct:1,exp:'Антитетический — контрастный: весна снаружи и зима в душе.'},
    ],
    9: [
      {theme:'Символика',text:'Символ в пейзаже — это деталь, которая...',opts:['Просто красива','Несёт дополнительный смысл, образ, идею','Обозначает время суток','Описывает климат'],correct:1,exp:'Символ несёт смысл за пределами буквального значения.'},
      {theme:'Символика',text:'Архетипический образ в литературе — это...',opts:['Образ из конкретного произведения','Универсальный образ, повторяющийся в культурах мира','Образ конкретного автора','Придуманный символ'],correct:1,exp:'Архетип — универсальный образ: лес=тайна, море=свобода во всех культурах.'},
    ],
    10: [
      {theme:'Анализ',text:'Пейзаж как "зеркало" общественных противоречий — это прежде всего характерно для...',opts:['Сказки','Реалистического романа XIX века','Детского рассказа','Басни'],correct:1,exp:'Реалистический роман использует пейзаж для отражения социальных и нравственных противоречий.'},
      {theme:'Анализ',text:'Чем отличается пейзаж у Толстого от пейзажа у Тургенева?',opts:['Ничем','Толстой использует пейзаж для психологического самораскрытия героев; Тургенев — для поэтических картин природы','Тургенев — только символы; Толстой — только фон','Оба только создают настроение'],correct:1,exp:'Толстой — психологический; Тургенев — поэтический и философский пейзаж.'},
    ],
    11: [
      {theme:'Теория',text:'Импрессионистический пейзаж в литературе — это...',opts:['Точное описание природы','Субъективное, фрагментарное ощущение природы через восприятие персонажа','Символический пейзаж','Исторический фон'],correct:1,exp:'Импрессионизм — субъективное впечатление, а не объективная картина.'},
      {theme:'Теория',text:'Пейзаж в модернистской литературе чаще всего...',opts:['Объективен и реалистичен','Разрушает привычные связи, создаёт многозначность и абсурд','Только создаёт настроение','Только символ'],correct:1,exp:'Модернизм деконструирует традиционные функции пейзажа, создавая новые смыслы.'},
    ],
  };
  return base.concat(grade_extra[grade] || []);
}

/* ===== QUIZ ENGINE ===== */
let _quizState = {
  questions: [], idx: 0, score: 0, answers: [], usedIds: new Set(), going: 'forward'
};

function quizShuffle(a) { return a.sort(() => Math.random() - .5); }

function startQuiz(grade, containerId, questionsPerSession = 15) {
  const pool = getQuestionsForGrade(grade);
  // Filter out recently used
  const available = pool.filter((_, i) => !_quizState.usedIds.has(i));
  const src = available.length >= questionsPerSession ? available : pool;
  if (available.length < questionsPerSession) _quizState.usedIds.clear();
  const shuffled = quizShuffle([...src]);
  const chosen = shuffled.slice(0, questionsPerSession);
  // Mark as used
  chosen.forEach(q => {
    const origIdx = pool.indexOf(q);
    if (origIdx >= 0) _quizState.usedIds.add(origIdx);
  });
  _quizState = { questions: chosen, idx: 0, score: 0, answers: Array(chosen.length).fill(null), usedIds: _quizState.usedIds, going: 'forward' };
  renderQuizQuestion(containerId);
}

function renderQuizQuestion(cid) {
  const s = _quizState;
  if (s.idx >= s.questions.length) { renderQuizResult(cid); return; }
  const q = s.questions[s.idx];
  const total = s.questions.length;
  const pct = Math.round(s.idx / total * 100);
  const letters = ['А','Б','В','Г'];
  const prev = s.answers[s.idx];
  const answered = prev !== null;
  const dir = s.going === 'back' ? 'going-back' : '';

  let html = `<div class="quiz-top-bar">
    <div class="quiz-prog-bar"><div class="quiz-prog-fill" style="width:${pct}%"></div></div>
    <div class="quiz-meta">
      <span>${s.idx+1} / ${total}</span>
      <span>✓ ${s.score}</span>
    </div>
  </div>
  <div class="quiz-card ${dir}" id="qcard">
    <span class="quiz-badge">${q.theme}</span>
    ${q.quote ? `<div class="quiz-quote">${q.quote}</div>` : ''}
    <div class="quiz-q-text">${q.text}</div>
    <div class="quiz-opts">`;

  q.opts.forEach((o, i) => {
    let cls = '';
    if (answered) {
      cls = 'locked ';
      if (i === q.correct) cls += 'correct';
      else if (i === prev) cls += 'wrong';
    }
    html += `<button class="quiz-opt ${cls}" ${answered ? 'disabled' : ''} onclick="selectQuizOpt(${i},'${cid}')">
      <span class="opt-let">${letters[i]}</span>${o}
    </button>`;
  });

  html += `</div>`;
  if (answered) {
    const ok = prev === q.correct;
    html += `<div class="quiz-feedback ${ok ? 'ok' : 'no'} show">
      ${ok ? '✓' : '✗'} ${q.exp}
    </div>`;
  }

  html += `<div class="quiz-nav-btns">
    <button class="btn-quiz-outline" onclick="quizBack('${cid}')" ${s.idx === 0 ? 'disabled style="opacity:.3;cursor:default;"' : ''}>← Назад</button>
    <div style="display:flex;gap:8px;">
      <button class="btn-quiz-finish" onclick="finishQuiz('${cid}')">Завершить тест</button>
      <button class="btn-quiz" onclick="quizNext('${cid}')" ${!answered ? 'disabled' : ''} id="qbtnNext">
        ${s.idx < total - 1 ? 'Далее →' : 'Результат →'}
      </button>
    </div>
  </div>
  </div>`;

  document.getElementById(cid).innerHTML = html;
}

function selectQuizOpt(idx, cid) {
  const s = _quizState;
  if (s.answers[s.idx] !== null) return;
  s.answers[s.idx] = idx;
  if (idx === s.questions[s.idx].correct) s.score++;
  renderQuizQuestion(cid);
}
function quizNext(cid) {
  _quizState.going = 'forward';
  _quizState.idx++;
  renderQuizQuestion(cid);
}
function quizBack(cid) {
  if (_quizState.idx === 0) return;
  _quizState.going = 'back';
  _quizState.idx--;
  renderQuizQuestion(cid);
}
function finishQuiz(cid) {
  // Count score from answered
  const s = _quizState;
  s.score = 0;
  s.answers.forEach((a, i) => { if (a !== null && a === s.questions[i].correct) s.score++; });
  renderQuizResult(cid);
}
function renderQuizResult(cid) {
  const s = _quizState;
  const answered = s.answers.filter(a => a !== null).length;
  const pct = answered > 0 ? Math.round(s.score / answered * 100) : 0;
  const stars = pct >= 80 ? '⭐⭐⭐' : pct >= 60 ? '⭐⭐' : '⭐';
  const title = pct >= 80 ? 'Превосходно!' : pct >= 60 ? 'Хорошая работа!' : 'Стоит повторить';
  const msg = pct >= 80 ? 'Ты отлично знаешь функции пейзажа!' : pct >= 60 ? 'Основа есть — перечитай теорию.' : 'Вернись к теории и попробуй снова.';
  const grade = document.getElementById(cid).dataset.grade || 7;
  document.getElementById(cid).innerHTML = `<div class="quiz-card quiz-result">
    <div class="res-stars">${stars}</div>
    <div class="res-num">${pct}%</div>
    <div class="res-label">${s.score} из ${answered} отвеченных вопросов</div>
    <div class="res-title">${title}</div>
    <div class="res-msg">${msg}</div>
    <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
      <button class="btn-quiz" onclick="startQuiz(${grade},'${cid}')">↺ Новые вопросы</button>
      <button class="btn-quiz-outline" onclick="document.getElementById('explore').scrollIntoView({behavior:'smooth'})">К творчеству →</button>
    </div>
  </div>`;
}

/* ===== AI CHAT ===== */
let chatHistory = [];
async function sendChat(grade) {
  const input = document.getElementById('chatInput');
  const msg = input.value.trim();
  if (!msg) return;
  input.value = '';
  const msgsEl = document.getElementById('chatMessages');
  chatHistory.push({ role: 'user', content: msg });
  msgsEl.innerHTML += `<div class="msg user">${msg}</div>`;
  const typingId = 'typing_' + Date.now();
  msgsEl.innerHTML += `<div class="msg ai typing-msg" id="${typingId}"><div class="typing"><span></span><span></span><span></span></div></div>`;
  msgsEl.scrollTop = msgsEl.scrollHeight;
  const btn = document.getElementById('chatSendBtn');
  if (btn) btn.disabled = true;
  const systemPrompt = `Ты — опытный учитель русской литературы. Ведёшь урок для ${grade} класса по теме "Роль пейзажа в художественном тексте". Отвечай кратко (3-5 предложений), по-русски, без markdown. Помогай ученику понять тему, задавай встречные вопросы, хвали за правильные ответы.`;
  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514', max_tokens: 500,
        system: systemPrompt,
        messages: chatHistory
      })
    });
    const data = await resp.json();
    const text = data.content?.map(b => b.text || '').join('') || 'Нет ответа.';
    chatHistory.push({ role: 'assistant', content: text });
    document.getElementById(typingId).remove();
    msgsEl.innerHTML += `<div class="msg ai">${text}</div>`;
  } catch (e) {
    document.getElementById(typingId).remove();
    msgsEl.innerHTML += `<div class="msg ai">Ошибка соединения.</div>`;
  }
  msgsEl.scrollTop = msgsEl.scrollHeight;
  if (btn) btn.disabled = false;
}

/* ===== EXPLORE AI FEEDBACK ===== */
async function submitExplore(idx, taskText, grade) {
  const answer = document.getElementById('etxt' + idx).value.trim();
  const fb = document.getElementById('earr' + idx);
  if (!answer) { fb.className = 'explore-ai show'; fb.textContent = 'Напиши свой ответ!'; return; }
  fb.className = 'explore-ai show';
  fb.innerHTML = '<div class="typing"><span></span><span></span><span></span></div>';
  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514', max_tokens: 450,
        messages: [{ role: 'user', content: `Ты — учитель литературы, ${grade} класс. Задание: "${taskText}"\n\nОтвет ученика: "${answer}"\n\nДай доброжелательный отзыв (4–5 предложений): что хорошо, что улучшить. Пиши по-русски, без markdown.` }]
      })
    });
    const data = await resp.json();
    fb.textContent = data.content?.map(b => b.text || '').join('') || 'Нет ответа.';
  } catch (e) { fb.textContent = 'Ошибка соединения.'; }
}

/* ===== PRINT ENGINE ===== */
function shuffleArr(a) { return [...a].sort(() => Math.random() - .5); }

function buildPrintVariant(varNum, qCount, grade, topicFilters, authorWork) {
  let pool = getQuestionsForGrade(grade);
  // Filter by topics
  if (topicFilters && topicFilters.length > 0) {
    pool = pool.filter(q => topicFilters.includes(q.theme) || q.theme === 'Произведение');
  }
  // Add work-specific questions
  if (authorWork && QB.works[authorWork]) {
    pool = pool.concat(QB.works[authorWork]);
  }
  // Use seed per variant to ensure different questions
  const seeded = shuffleArr(pool);
  // For different class sessions, offset by a large prime based on variant + grade
  const offset = ((varNum * 37 + grade * 13 + Math.floor(Date.now() / 86400000)) % seeded.length);
  const rotated = [...seeded.slice(offset), ...seeded.slice(0, offset)];
  const questions = rotated.slice(0, Math.min(qCount, rotated.length));
  const letters = ['А', 'Б', 'В', 'Г'];
  const className = document.getElementById('pcClass')?.value || '';
  const answers = [];
  let qNum = 1;

  const useChoice = document.getElementById('ptChoice')?.checked !== false;
  const useOpen = document.getElementById('ptOpen')?.checked;
  const useCite = document.getElementById('ptCite')?.checked !== false;
  const useMatch = document.getElementById('ptMatch')?.checked;
  const useMini = document.getElementById('ptMini')?.checked;

  let html = `<div style="font-family:'Times New Roman',serif;max-width:740px;margin:0 auto;padding:24px 32px;font-size:14px;line-height:1.6;color:#111;">`;
  html += `<div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #1a3a2a;padding-bottom:12px;margin-bottom:20px;">
    <div>
      <div style="font-size:10px;color:#666;letter-spacing:.12em;text-transform:uppercase;">Контрольная работа · Литература · ${grade} класс</div>
      <div style="font-size:17px;font-weight:bold;margin-top:4px;">Роль пейзажа в художественном тексте</div>
      ${authorWork ? `<div style="font-size:12px;color:#444;margin-top:2px;">Произведение: ${authorWork}</div>` : ''}
      ${className ? `<div style="font-size:12px;color:#444;margin-top:1px;">Класс: ${className}</div>` : ''}
    </div>
    <div style="text-align:right;">
      <div style="font-size:26px;font-weight:900;color:#1a3a2a;font-family:'Times New Roman',serif;">Вариант ${varNum}</div>
      <div style="font-size:11px;color:#666;margin-top:3px;">Дата: ___________</div>
      <div style="font-size:11px;color:#666;">Имя: _________________________</div>
    </div>
  </div>`;

  questions.forEach((q, i) => {
    const isMini = useMini && (i % 12 === 11);
    const isOpen = !isMini && useOpen && (i % 6 === 5);
    const doShuffle = true;
    html += `<div style="margin-bottom:18px;page-break-inside:avoid;">`;
    if (isMini) {
      html += `<div style="font-weight:bold;margin-bottom:5px;">${qNum}. ${q.text}</div>`;
      if (q.quote) html += `<div style="border-left:3px solid #1a3a2a;padding:7px 11px;margin-bottom:7px;font-style:italic;background:#f8f8f8;font-size:13px;">${q.quote}</div>`;
      html += `<div style="font-size:11px;color:#666;margin-bottom:4px;">Запишите развёрнутый ответ (3–5 предложений):</div>`;
      html += `<div style="border:1px solid #bbb;min-height:88px;padding:6px;border-radius:3px;font-size:12px;color:#aaa;font-style:italic;">Место для ответа</div>`;
      answers.push({ n: qNum, type: 'mini', correct: q.opts[q.correct], exp: q.exp });
    } else if (isOpen) {
      html += `<div style="font-weight:bold;margin-bottom:5px;">${qNum}. ${q.text}</div>`;
      if (q.quote) html += `<div style="border-left:3px solid #1a3a2a;padding:7px 11px;margin-bottom:7px;font-style:italic;background:#f8f8f8;font-size:13px;">${q.quote}</div>`;
      html += `<div style="font-size:11px;color:#666;margin-bottom:3px;">Ответьте своими словами:</div>`;
      html += `<div style="border-bottom:1px dashed #999;height:24px;margin-bottom:5px;"></div><div style="border-bottom:1px dashed #999;height:24px;"></div>`;
      answers.push({ n: qNum, type: 'open', correct: q.opts[q.correct], exp: q.exp });
    } else {
      html += `<div style="font-weight:bold;margin-bottom:5px;">${qNum}. ${q.text}</div>`;
      if (q.quote) html += `<div style="border-left:3px solid #1a3a2a;padding:7px 11px;margin-bottom:7px;font-style:italic;background:#f8f8f8;font-size:13px;">${q.quote}</div>`;
      const opts = q.opts.map((o, i) => ({ o, orig: i }));
      if (doShuffle) shuffleArr(opts);
      const newCorrect = opts.findIndex(x => x.orig === q.correct);
      html += `<div style="display:grid;grid-template-columns:1fr 1fr;gap:3px 18px;">`;
      opts.forEach((item, i) => { html += `<div style="padding:3px 0;font-size:13px;">${letters[i]}) ${item.o}</div>`; });
      html += `</div><div style="margin-top:5px;font-size:12px;">Ответ: ____</div>`;
      answers.push({ n: qNum, type: 'choice', correct: letters[newCorrect], text: opts[newCorrect].o, exp: q.exp });
    }
    html += `</div>`;
    qNum++;
  });

  html += `<div style="margin-top:28px;border-top:1px solid #aaa;padding-top:10px;display:flex;justify-content:space-between;font-size:10px;color:#888;">
    <span>© 2026 Рустам Шестопалов — Все права защищены</span>
    <a href="https://bibl-rshest.ru" style="color:#1a3a2a;text-decoration:none;">bibl-rshest.ru</a>
  </div></div>`;
  return { html, answers, varNum, qCount: qNum - 1 };
}

function buildAnswerKey(variants, grade, authorWork) {
  let html = `<div style="font-family:'Times New Roman',serif;max-width:740px;margin:0 auto;padding:28px 32px;font-size:13px;color:#111;">`;
  html += `<div style="background:#1a3a2a;color:#fff;padding:18px 22px;border-radius:6px;margin-bottom:26px;">
    <div style="font-size:10px;letter-spacing:.14em;opacity:.65;text-transform:uppercase;">Только для учителя · ${grade} класс</div>
    <div style="font-size:20px;font-weight:bold;margin-top:3px;">Ключ ответов</div>
    <div style="font-size:13px;opacity:.75;margin-top:3px;">Роль пейзажа в художественном тексте${authorWork ? ' · ' + authorWork : ''}</div>
  </div>`;
  variants.forEach(v => {
    html += `<div style="margin-bottom:36px;page-break-inside:avoid;">
      <div style="font-size:15px;font-weight:bold;border-bottom:2px solid #1a3a2a;padding-bottom:5px;margin-bottom:14px;color:#1a3a2a;">Вариант ${v.varNum} (${v.qCount} вопросов)</div>
      <table style="width:100%;border-collapse:collapse;font-size:12px;">
        <thead><tr style="background:#e8f2ec;">
          <th style="padding:7px 8px;text-align:left;border:1px solid #ccc;width:42px;">№</th>
          <th style="padding:7px 8px;text-align:left;border:1px solid #ccc;width:70px;">Ответ</th>
          <th style="padding:7px 8px;text-align:left;border:1px solid #ccc;">Правильный ответ и пояснение</th>
        </tr></thead><tbody>`;
    v.answers.forEach(a => {
      html += `<tr>
        <td style="padding:6px 8px;border:1px solid #ddd;font-weight:bold;">${a.n}</td>
        <td style="padding:6px 8px;border:1px solid #ddd;color:#1a3a2a;font-weight:bold;">${a.type === 'choice' ? a.correct : '(развёрнутый)'}</td>
        <td style="padding:6px 8px;border:1px solid #ddd;">${a.type === 'choice' || a.type === 'open' ? a.text + ' — ' : ''}<span style="color:#555;font-style:italic;">${a.exp}</span></td>
      </tr>`;
    });
    html += `</tbody></table></div>`;
  });
  html += `<div style="margin-top:24px;border-top:1px solid #aaa;padding-top:10px;display:flex;justify-content:space-between;font-size:10px;color:#888;">
    <span>© 2026 Рустам Шестопалов — Все права защищены</span>
    <a href="https://bibl-rshest.ru" style="color:#1a3a2a;">bibl-rshest.ru</a>
  </div></div>`;
  return html;
}

function doPrintStudents(grade) {
  const qCount = parseInt(document.getElementById('pcQCount').value);
  const vCount = parseInt(document.getElementById('pcVarCount').value);
  const topicFilters = getSelectedTopics();
  const authorWork = getSelectedWork();
  const variants = [];
  for (let i = 1; i <= vCount; i++) variants.push(buildPrintVariant(i, qCount, grade, topicFilters, authorWork));
  const w = window.open('', '_blank');
  w.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Варианты ${grade} класс</title>
  <style>body{margin:0;background:#fff;} @media print{.pb{page-break-after:always;} @page{margin:12mm;}} a{color:#1a3a2a;}</style>
  </head><body>`);
  variants.forEach((v, i) => { w.document.write(v.html); if (i < variants.length - 1) w.document.write('<div class="pb"></div>'); });
  w.document.write(`<script>window.onload=()=>window.print();<\/script></body></html>`);
  w.document.close();
}

function doPrintTeacher(grade) {
  const qCount = parseInt(document.getElementById('pcQCount').value);
  const vCount = parseInt(document.getElementById('pcVarCount').value);
  const topicFilters = getSelectedTopics();
  const authorWork = getSelectedWork();
  const variants = [];
  for (let i = 1; i <= vCount; i++) variants.push(buildPrintVariant(i, qCount, grade, topicFilters, authorWork));
  const keyHtml = buildAnswerKey(variants, grade, authorWork);
  const w = window.open('', '_blank');
  w.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Ключ ${grade} класс</title>
  <style>body{margin:0;background:#fff;} @media print{@page{margin:12mm;}} a{color:#1a3a2a;}</style>
  </head><body>${keyHtml}<script>window.onload=()=>window.print();<\/script></body></html>`);
  w.document.close();
}

function getSelectedTopics() {
  const checks = document.querySelectorAll('.topic-check:checked');
  const topics = Array.from(checks).map(c => c.value);
  return topics.length > 0 ? topics : null;
}

function getSelectedWork() {
  const sel = document.getElementById('pcWork');
  return sel && sel.value ? sel.value : null;
}

/* ===== INIT ===== */
window.addEventListener('DOMContentLoaded', () => {
  initCursorScroll();
  initReveal();
  initParticles('heroParticles');
  initTheoryTabs();
  initTimer(35);
  const grade = parseInt(document.body.dataset.grade || '7');
  const qArena = document.getElementById('quizArena');
  if (qArena) { qArena.dataset.grade = grade; startQuiz(grade, 'quizArena'); }
  // Author/work selector
  const authorSel = document.getElementById('pcAuthor');
  const workSel = document.getElementById('pcWork');
  if (authorSel && workSel) {
    authorSel.addEventListener('change', () => {
      const works = getWorksForAuthor(authorSel.value);
      workSel.innerHTML = '<option value="">— выберите произведение —</option>';
      works.forEach(w => { workSel.innerHTML += `<option value="${w}">${w}</option>`; });
    });
  }
});

function getWorksForAuthor(author) {
  const map = {
    'Пушкин А.С.': ['Капитанская дочка (Пушкин)', 'Евгений Онегин (Пушкин)'],
    'Лермонтов М.Ю.': ['Мцыри (Лермонтов)'],
    'Гоголь Н.В.': ['Мёртвые души (Гоголь)'],
    'Островский А.Н.': ['Гроза (Островский)'],
    'Толстой Л.Н.': ['Война и мир (Толстой)'],
    'Чехов А.П.': ['Вишнёвый сад (Чехов)'],
    'Шолохов М.А.': ['Тихий Дон (Шолохов)'],
    'Неизвестный автор': ['Слово о полку Игореве'],
  };
  return map[author] || [];
}
